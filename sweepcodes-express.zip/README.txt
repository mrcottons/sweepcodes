SWEEPCODES (Express + SQLite) - cPanel/Namecheap friendly
========================================================

This is a complete working SweepCodes site:
- Public site: Home, Casinos directory, Casino landing pages, Compare, Blog, Legal pages
- Admin-only CMS: add/edit casinos, blog posts, and legal pages
- No public accounts (ONLY admin login)

--------------------------------------------------------
1) Upload (Phone-friendly)
--------------------------------------------------------
Option A (recommended): Upload the ZIP and extract in cPanel File Manager.

- In cPanel > File Manager
- Go to your Node.js "Application Root" folder (example: /home/USER/sweepcodes)
- Upload this zip, then Extract here.
- Ensure server.js and package.json are directly inside the Application Root.

--------------------------------------------------------
2) Set Environment Variables in cPanel
--------------------------------------------------------
In cPanel > Setup Node.js App > (your app) > Environment Variables, add:

NODE_ENV = production
ADMIN_EMAIL = your email
ADMIN_PASSWORD = your password
SESSION_SECRET = long random string 32+ chars
BASE_URL = https://your-domain

(Do NOT use quotes.) Save.

--------------------------------------------------------
3) Install + Restart
--------------------------------------------------------
In cPanel > Setup Node.js App:
- Click "Run NPM Install"
- Click "Restart" (or Start)

Then visit your site URL. You should see the SweepCodes homepage.

--------------------------------------------------------
4) Admin Login
--------------------------------------------------------
Go to: /admin/login
Login with ADMIN_EMAIL + ADMIN_PASSWORD (from env vars).

Admin area:
- /admin (dashboard)
- /admin/casinos (create/edit casinos)
- /admin/posts (create/edit blog posts)
- /admin/pages (edit privacy/terms/disclaimer)

--------------------------------------------------------
5) Database
--------------------------------------------------------
SQLite file is stored at: /data/sweepcodes.db
It is created automatically on first run.

--------------------------------------------------------
6) Notes
--------------------------------------------------------
Affiliate CTAs open in a new tab and include rel="nofollow sponsored".
This is a starter. You can add images by pasting image URLs (CDN or hosted files) for logos and featured images.

Enjoy.
