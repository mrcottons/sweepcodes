const path = require("path");
const fs = require("fs");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const cookieParser = require("cookie-parser");
const dotenv = require("dotenv");
dotenv.config();

const Database = require("better-sqlite3");

const app = express();

// --- Security / middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(rateLimit({ windowMs: 60 * 1000, max: 300 }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser(process.env.SESSION_SECRET || "dev-secret"));

// --- Views / static
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use("/public", express.static(path.join(__dirname, "public"), { maxAge: "7d" }));

// --- EJS layout helper (tiny)
app.use((req, res, next) => {
  res.locals.layout = function(layoutName, locals) {
    // no-op helper for compatibility with our templates
    // In EJS, we simulate layouts by rendering body into layout via express-ejs-layouts style,
    // but without extra deps. We'll do it manually in a wrapper render below.
  };
  next();
});

function render(res, view, params) {
  // Render view to string, then inject into layout.ejs
  const ejs = require("ejs");
  const viewsDir = app.get("views");
  const viewPath = path.join(viewsDir, view + ".ejs");
  const layoutPath = path.join(viewsDir, "layout.ejs");

  const body = ejs.render(fs.readFileSync(viewPath, "utf-8"), params, {
    filename: viewPath
  });

  const html = ejs.render(fs.readFileSync(layoutPath, "utf-8"), { ...params, body }, {
    filename: layoutPath
  });

  res.send(html);
}

// --- DB init
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbPath = path.join(dataDir, "sweepcodes.db");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");

// Schema
db.exec(`
CREATE TABLE IF NOT EXISTS casinos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  logo_url TEXT,
  short_tagline TEXT,
  bonus_headline TEXT,
  bonus_details TEXT,
  promo_code TEXT,
  affiliate_url TEXT NOT NULL,
  us_allowed INTEGER NOT NULL DEFAULT 1,
  supported_states_notes TEXT,
  instant_redemption_verified INTEGER NOT NULL DEFAULT 0,
  crypto_accepted INTEGER NOT NULL DEFAULT 0,
  provably_fair INTEGER NOT NULL DEFAULT 0,
  is_new INTEGER NOT NULL DEFAULT 0,
  redemption_speed TEXT,
  min_redemption TEXT,
  kyc_notes TEXT,
  seo_title TEXT,
  seo_description TEXT,
  og_image_url TEXT,
  published INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_casinos_pub ON casinos(published);
CREATE INDEX IF NOT EXISTS idx_casinos_slug ON casinos(slug);

CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  excerpt TEXT,
  featured_image TEXT,
  content TEXT NOT NULL,
  category TEXT,
  tags_csv TEXT,
  published INTEGER NOT NULL DEFAULT 1,
  publish_date TEXT NOT NULL DEFAULT (datetime('now')),
  seo_title TEXT,
  seo_description TEXT,
  og_image_url TEXT,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_posts_slug ON posts(slug);

CREATE TABLE IF NOT EXISTS pages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
`);

// Seed legal pages
const seedPage = db.prepare(`INSERT OR IGNORE INTO pages (slug, title, content) VALUES (?, ?, ?)`);
seedPage.run("privacy", "Privacy Policy", "<p>Add your privacy policy here.</p>");
seedPage.run("terms", "Terms of Use", "<p>Add your terms here.</p>");
seedPage.run("disclaimer", "Disclaimer", "<p>Add your disclaimer here.</p>");

// Seed starter content if empty
const casinosCount = db.prepare("SELECT COUNT(*) as n FROM casinos").get().n;
if (casinosCount === 0) {
  const ins = db.prepare(`
    INSERT INTO casinos
    (name, slug, logo_url, short_tagline, bonus_headline, bonus_details, promo_code, affiliate_url,
     instant_redemption_verified, crypto_accepted, provably_fair, is_new, redemption_speed, min_redemption, kyc_notes, supported_states_notes, published)
    VALUES
    (@name, @slug, @logo_url, @short_tagline, @bonus_headline, @bonus_details, @promo_code, @affiliate_url,
     @instant_redemption_verified, @crypto_accepted, @provably_fair, @is_new, @redemption_speed, @min_redemption, @kyc_notes, @supported_states_notes, @published)
  `);
  const starter = [
    {
      name: "LuckyBird",
      slug: "luckybird",
      logo_url: "",
      short_tagline: "Fast-paced sweeps play with daily promos.",
      bonus_headline: "Get a starter bonus + daily drops",
      bonus_details: "<p>Use your affiliate link to sign up and check current welcome offers.</p><ul><li>Daily promos</li><li>Mobile-friendly</li></ul>",
      promo_code: "SWEEPCODES",
      affiliate_url: "https://example.com/affiliate/luckybird",
      instant_redemption_verified: 1,
      crypto_accepted: 1,
      provably_fair: 0,
      is_new: 1,
      redemption_speed: "Instant",
      min_redemption: "$20",
      kyc_notes: "May require ID at redemption thresholds.",
      supported_states_notes: "US-allowed where sweepstakes are permitted.",
      published: 1
    },
    {
      name: "Zitobox",
      slug: "zitobox",
      logo_url: "",
      short_tagline: "Clean UI and simple promos.",
      bonus_headline: "New user welcome bundle",
      bonus_details: "<p>Welcome bundle varies. Always verify eligibility and T&Cs.</p>",
      promo_code: "",
      affiliate_url: "https://example.com/affiliate/zitobox",
      instant_redemption_verified: 0,
      crypto_accepted: 1,
      provably_fair: 1,
      is_new: 1,
      redemption_speed: "<24h",
      min_redemption: "$10",
      kyc_notes: "KYC may be required for larger withdrawals.",
      supported_states_notes: "US-allowed (check restricted states).",
      published: 1
    },
    {
      name: "Stake-Style Crypto",
      slug: "stake-style-crypto",
      logo_url: "",
      short_tagline: "Provably fair crypto games & quick action.",
      bonus_headline: "Crypto promos + provably fair",
      bonus_details: "<p>Crypto accepted. Provably fair verification available per game.</p>",
      promo_code: "SWEEP10",
      affiliate_url: "https://example.com/affiliate/stake-style",
      instant_redemption_verified: 1,
      crypto_accepted: 1,
      provably_fair: 1,
      is_new: 0,
      redemption_speed: "Instant",
      min_redemption: "$25",
      kyc_notes: "Depends on provider; read rules.",
      supported_states_notes: "US-only where permitted (verify).",
      published: 1
    }
  ];
  starter.forEach(row => ins.run(row));
}

const postsCount = db.prepare("SELECT COUNT(*) as n FROM posts").get().n;
if (postsCount === 0) {
  const insP = db.prepare(`
    INSERT INTO posts (title, slug, excerpt, content, category, tags_csv, published)
    VALUES (@title, @slug, @excerpt, @content, @category, @tags_csv, @published)
  `);
  const starterPosts = [
    {
      title: "Instant Redemption: What it really means",
      slug: "instant-redemption-what-it-means",
      excerpt: "Our ‘Instant Redemption Verified’ badge is reserved for casinos we’ve verified can redeem quickly.",
      content: "<p>Instant redemption varies by casino, payment method, and verification status. Our badge is used when you’ve verified consistent instant or near-instant cashout behavior.</p><p>Always confirm current terms on the casino landing page.</p>",
      category: "Guides",
      tags_csv: "instant,redemption",
      published: 1
    },
    {
      title: "How to compare casinos like a pro",
      slug: "how-to-compare-casinos-like-a-pro",
      excerpt: "Use Compare to stack bonus, speed, min redemption, and key flags side-by-side.",
      content: "<p>Tap Compare and add up to three casinos. Focus on redemption speed, minimum redemption, and eligibility notes.</p>",
      category: "Tools",
      tags_csv: "compare,tools",
      published: 1
    }
  ];
  starterPosts.forEach(p => insP.run(p));
}

// --- Helpers
function slugify(str = "") {
  return str.toLowerCase().trim()
    .replace(/['"]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

function boolToInt(v) {
  return v === "on" || v === "true" || v === "1" ? 1 : 0;
}

function isAuthed(req) {
  const v = req.signedCookies?.sc_admin;
  return v && v === (process.env.ADMIN_EMAIL || "");
}

function requireAdmin(req, res, next) {
  if (!isAuthed(req)) return res.redirect("/admin/login");
  next();
}

function metaFor(req, meta) {
  const base = (process.env.BASE_URL || "").replace(/\/$/, "");
  const canonical = base ? base + req.path : undefined;
  return { ...meta, canonical };
}

// --- Prepared statements
const qFeatured = db.prepare(`
  SELECT * FROM casinos
  WHERE published=1 AND us_allowed=1
  ORDER BY instant_redemption_verified DESC, is_new DESC, datetime(updated_at) DESC
  LIMIT 12
`);

const qInstant = db.prepare(`
  SELECT * FROM casinos
  WHERE published=1 AND us_allowed=1 AND instant_redemption_verified=1
  ORDER BY datetime(updated_at) DESC
  LIMIT 12
`);

const qAllCasinos = db.prepare(`
  SELECT * FROM casinos
  WHERE published=1 AND us_allowed=1
  ORDER BY is_new DESC, datetime(updated_at) DESC
`);

const qCasinoBySlug = db.prepare(`
  SELECT * FROM casinos
  WHERE published=1 AND slug=?
  LIMIT 1
`);

const qLatestPosts = db.prepare(`
  SELECT * FROM posts
  WHERE published=1
  ORDER BY datetime(publish_date) DESC
  LIMIT 6
`);

const qPosts = db.prepare(`
  SELECT * FROM posts
  WHERE published=1
  ORDER BY datetime(publish_date) DESC
`);

const qPostBySlug = db.prepare(`
  SELECT * FROM posts
  WHERE published=1 AND slug=?
  LIMIT 1
`);

const qPageBySlug = db.prepare(`
  SELECT * FROM pages
  WHERE slug=?
  LIMIT 1
`);

// Admin queries
const qaCounts = {
  casinos: db.prepare("SELECT COUNT(*) n FROM casinos"),
  casinosPub: db.prepare("SELECT COUNT(*) n FROM casinos WHERE published=1"),
  instant: db.prepare("SELECT COUNT(*) n FROM casinos WHERE published=1 AND instant_redemption_verified=1"),
  crypto: db.prepare("SELECT COUNT(*) n FROM casinos WHERE published=1 AND crypto_accepted=1"),
  provably: db.prepare("SELECT COUNT(*) n FROM casinos WHERE published=1 AND provably_fair=1"),
  posts: db.prepare("SELECT COUNT(*) n FROM posts"),
  postsPub: db.prepare("SELECT COUNT(*) n FROM posts WHERE published=1"),
};
const qaCasinos = db.prepare("SELECT * FROM casinos ORDER BY datetime(updated_at) DESC");
const qaCasinoById = db.prepare("SELECT * FROM casinos WHERE id=?");
const qaPosts = db.prepare("SELECT * FROM posts ORDER BY datetime(publish_date) DESC");
const qaPostById = db.prepare("SELECT * FROM posts WHERE id=?");
const qaPages = db.prepare("SELECT * FROM pages ORDER BY slug ASC");
const qaPageById = db.prepare("SELECT * FROM pages WHERE id=?");

// --- PUBLIC ROUTES
app.get("/", (req, res) => {
  const featured = qFeatured.all();
  const instant = qInstant.all();
  const posts = qLatestPosts.all();
  const all = qAllCasinos.all();
  const stats = {
    total: all.length,
    instant: all.filter(c => c.instant_redemption_verified).length,
    crypto: all.filter(c => c.crypto_accepted).length,
    provably: all.filter(c => c.provably_fair).length
  };

  render(res, "index", {
    active: "home",
    meta: metaFor(req, {
      title: "SweepCodes — Bonus Codes & Casinos",
      description: "US-allowed sweepstakes + crypto casinos with sleek cards, instant redemption verification, and clean comparisons.",
      ogTitle: "SweepCodes — Bonus Codes & Casinos"
    }),
    featured,
    instant,
    posts,
    stats
  });
});

app.get("/casinos", (req, res) => {
  const search = (req.query.search || "").toString().trim().toLowerCase();
  const q = {
    search: req.query.search || "",
    instant: req.query.instant === "1",
    crypto: req.query.crypto === "1",
    provably: req.query.provably === "1",
    isNew: req.query.new === "1",
  };

  let casinos = qAllCasinos.all();
  if (search) casinos = casinos.filter(c => (c.name || "").toLowerCase().includes(search));
  if (q.instant) casinos = casinos.filter(c => c.instant_redemption_verified === 1);
  if (q.crypto) casinos = casinos.filter(c => c.crypto_accepted === 1);
  if (q.provably) casinos = casinos.filter(c => c.provably_fair === 1);
  if (q.isNew) casinos = casinos.filter(c => c.is_new === 1);

  render(res, "casinos", {
    active: "casinos",
    meta: metaFor(req, { title: "Casinos — SweepCodes", description: "Browse and filter casinos: instant redemption, crypto, provably fair, and new." }),
    casinos,
    q
  });
});

app.get("/casinos/:slug", (req, res) => {
  const casino = qCasinoBySlug.get(req.params.slug);
  if (!casino) return res.status(404).send("Not found");

  // related: pick by matching flags
  const all = qAllCasinos.all();
  const related = all
    .filter(c => c.slug !== casino.slug)
    .sort((a,b) => {
      const score = (x) => (x.instant_redemption_verified === casino.instant_redemption_verified) + (x.crypto_accepted === casino.crypto_accepted) + (x.provably_fair === casino.provably_fair) + (x.is_new === casino.is_new);
      return score(b) - score(a);
    })
    .slice(0, 6);

  render(res, "casino", {
    active: "casinos",
    meta: metaFor(req, {
      title: (casino.seo_title || `${casino.name} — SweepCodes`),
      description: casino.seo_description || casino.short_tagline || `Bonus details, redemption speed, and claim link for ${casino.name}.`,
      ogImage: casino.og_image_url || undefined
    }),
    casino,
    related
  });
});

app.get("/compare", (req, res) => {
  // selection is kept in query via add/remove parameters; also allow passing s=slug1,slug2,slug3
  const all = qAllCasinos.all();
  const current = new Set(
    (req.query.s ? req.query.s.toString().split(",") : [])
      .map(s => s.trim())
      .filter(Boolean)
  );

  if (req.query.add) current.add(req.query.add.toString());
  if (req.query.remove) current.delete(req.query.remove.toString());

  const selectedSlugs = Array.from(current).slice(0, 3);
  const selected = selectedSlugs.map(slug => all.find(c => c.slug === slug)).filter(Boolean);

  const search = (req.query.search || "").toString().trim().toLowerCase();
  let results = [];
  if (search) {
    results = all.filter(c => (c.name || "").toLowerCase().includes(search)).slice(0, 8);
  }

  // rebuild s param so add/remove persists
  const sParam = selectedSlugs.join(",");
  // If user used add/remove without s, redirect to canonical compare with s param to keep state
  if ((req.query.add || req.query.remove) && req.query.s !== sParam) {
    const qs = new URLSearchParams();
    if (sParam) qs.set("s", sParam);
    if (search) qs.set("search", req.query.search.toString());
    return res.redirect("/compare" + (qs.toString() ? "?" + qs.toString() : ""));
  }

  render(res, "compare", {
    active: "compare",
    meta: metaFor(req, { title: "Compare — SweepCodes", description: "Compare up to 3 casinos side-by-side: bonus, redemption speed, min redemption, and flags." }),
    selected,
    results,
    q: { search: req.query.search || "" }
  });
});

app.get("/blog", (req, res) => {
  const posts = qPosts.all();
  render(res, "blog", {
    active: "blog",
    meta: metaFor(req, { title: "Blog — SweepCodes", description: "Updates, bonus drops, and guides." }),
    posts
  });
});

app.get("/blog/:slug", (req, res) => {
  const post = qPostBySlug.get(req.params.slug);
  if (!post) return res.status(404).send("Not found");
  render(res, "post", {
    active: "blog",
    meta: metaFor(req, {
      title: post.seo_title || `${post.title} — SweepCodes`,
      description: post.seo_description || post.excerpt || "SweepCodes blog post.",
      ogImage: post.og_image_url || undefined
    }),
    post
  });
});

app.get("/:slug(privacy|terms|disclaimer)", (req, res) => {
  const page = qPageBySlug.get(req.params.slug);
  if (!page) return res.status(404).send("Not found");
  render(res, "page", {
    active: "",
    meta: metaFor(req, { title: `${page.title} — SweepCodes`, description: `${page.title} for SweepCodes.` }),
    page
  });
});

// --- ADMIN ROUTES
app.get("/admin/login", (req, res) => {
  render(res, "admin/login", { active: "", meta: metaFor(req, { title: "Admin Login — SweepCodes", description: "" }), error: null });
});

app.post("/admin/login", (req, res) => {
  const email = (req.body.email || "").toString().trim();
  const password = (req.body.password || "").toString();

  if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD) {
    return render(res, "admin/login", { active: "", meta: metaFor(req, { title: "Admin Login — SweepCodes" }), error: "Missing ADMIN_EMAIL / ADMIN_PASSWORD in environment variables." });
  }

  if (email === process.env.ADMIN_EMAIL && password === process.env.ADMIN_PASSWORD) {
    res.cookie("sc_admin", process.env.ADMIN_EMAIL, { signed: true, httpOnly: true, sameSite: "lax", secure: false });
    return res.redirect("/admin");
  }
  return render(res, "admin/login", { active: "", meta: metaFor(req, { title: "Admin Login — SweepCodes" }), error: "Check your ADMIN_EMAIL / ADMIN_PASSWORD." });
});

app.get("/admin/logout", (req, res) => {
  res.clearCookie("sc_admin");
  res.redirect("/");
});

app.get("/admin", requireAdmin, (req, res) => {
  const counts = {
    casinos: qaCounts.casinos.get().n,
    casinos_pub: qaCounts.casinosPub.get().n,
    instant: qaCounts.instant.get().n,
    crypto: qaCounts.crypto.get().n,
    provably: qaCounts.provably.get().n,
    posts: qaCounts.posts.get().n,
    posts_pub: qaCounts.postsPub.get().n,
  };
  render(res, "admin/dashboard", { active: "", meta: metaFor(req, { title: "Admin — SweepCodes" }), counts });
});

// Casinos CRUD
app.get("/admin/casinos", requireAdmin, (req, res) => {
  const casinos = qaCasinos.all();
  render(res, "admin/casinos_list", { active: "", meta: metaFor(req, { title: "Admin Casinos — SweepCodes" }), casinos });
});

app.get("/admin/casinos/new", requireAdmin, (req, res) => {
  render(res, "admin/casinos_form", { active: "", meta: metaFor(req, { title: "Add Casino — SweepCodes" }), casino: null });
});

app.post("/admin/casinos", requireAdmin, (req, res) => {
  const body = req.body || {};
  const name = (body.name || "").toString().trim();
  if (!name) return res.status(400).send("Name required");

  let slug = (body.slug || "").toString().trim();
  if (!slug) slug = slugify(name);

  const stmt = db.prepare(`
    INSERT INTO casinos
    (name, slug, logo_url, short_tagline, bonus_headline, bonus_details, promo_code, affiliate_url,
     instant_redemption_verified, crypto_accepted, provably_fair, is_new, redemption_speed, min_redemption,
     kyc_notes, supported_states_notes, seo_title, seo_description, og_image_url, published, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
  `);

  try {
    stmt.run(
      name,
      slug,
      (body.logo_url || "").toString().trim(),
      (body.short_tagline || "").toString().trim(),
      (body.bonus_headline || "").toString().trim(),
      (body.bonus_details || "").toString().trim(),
      (body.promo_code || "").toString().trim(),
      (body.affiliate_url || "").toString().trim(),
      boolToInt(body.instant_redemption_verified),
      boolToInt(body.crypto_accepted),
      boolToInt(body.provably_fair),
      boolToInt(body.is_new),
      (body.redemption_speed || "Unknown").toString(),
      (body.min_redemption || "").toString().trim(),
      (body.kyc_notes || "").toString().trim(),
      (body.supported_states_notes || "").toString().trim(),
      (body.seo_title || "").toString().trim(),
      (body.seo_description || "").toString().trim(),
      (body.og_image_url || "").toString().trim(),
      boolToInt(body.published)
    );
  } catch (e) {
    return res.status(400).send("Error creating casino: " + e.message);
  }
  res.redirect("/admin/casinos");
});

app.get("/admin/casinos/:id/edit", requireAdmin, (req, res) => {
  const casino = qaCasinoById.get(req.params.id);
  if (!casino) return res.status(404).send("Not found");
  render(res, "admin/casinos_form", { active: "", meta: metaFor(req, { title: "Edit Casino — SweepCodes" }), casino });
});

app.post("/admin/casinos/:id", requireAdmin, (req, res) => {
  const body = req.body || {};
  const id = req.params.id;
  const current = qaCasinoById.get(id);
  if (!current) return res.status(404).send("Not found");

  const name = (body.name || "").toString().trim();
  let slug = (body.slug || "").toString().trim();
  if (!slug) slug = slugify(name);

  const stmt = db.prepare(`
    UPDATE casinos SET
      name=?, slug=?, logo_url=?, short_tagline=?, bonus_headline=?, bonus_details=?, promo_code=?, affiliate_url=?,
      instant_redemption_verified=?, crypto_accepted=?, provably_fair=?, is_new=?, redemption_speed=?, min_redemption=?,
      kyc_notes=?, supported_states_notes=?, seo_title=?, seo_description=?, og_image_url=?, published=?,
      updated_at=datetime('now')
    WHERE id=?
  `);

  try {
    stmt.run(
      name,
      slug,
      (body.logo_url || "").toString().trim(),
      (body.short_tagline || "").toString().trim(),
      (body.bonus_headline || "").toString().trim(),
      (body.bonus_details || "").toString().trim(),
      (body.promo_code || "").toString().trim(),
      (body.affiliate_url || "").toString().trim(),
      boolToInt(body.instant_redemption_verified),
      boolToInt(body.crypto_accepted),
      boolToInt(body.provably_fair),
      boolToInt(body.is_new),
      (body.redemption_speed || "Unknown").toString(),
      (body.min_redemption || "").toString().trim(),
      (body.kyc_notes || "").toString().trim(),
      (body.supported_states_notes || "").toString().trim(),
      (body.seo_title || "").toString().trim(),
      (body.seo_description || "").toString().trim(),
      (body.og_image_url || "").toString().trim(),
      boolToInt(body.published),
      id
    );
  } catch (e) {
    return res.status(400).send("Error updating casino: " + e.message);
  }
  res.redirect("/admin/casinos");
});

app.post("/admin/casinos/:id/delete", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM casinos WHERE id=?").run(req.params.id);
  res.redirect("/admin/casinos");
});

// Posts CRUD
app.get("/admin/posts", requireAdmin, (req, res) => {
  const posts = qaPosts.all();
  render(res, "admin/posts_list", { active: "", meta: metaFor(req, { title: "Admin Posts — SweepCodes" }), posts });
});

app.get("/admin/posts/new", requireAdmin, (req, res) => {
  render(res, "admin/posts_form", { active: "", meta: metaFor(req, { title: "Add Post — SweepCodes" }), post: null });
});

app.post("/admin/posts", requireAdmin, (req, res) => {
  const body = req.body || {};
  const title = (body.title || "").toString().trim();
  if (!title) return res.status(400).send("Title required");

  let slug = (body.slug || "").toString().trim();
  if (!slug) slug = slugify(title);

  const stmt = db.prepare(`
    INSERT INTO posts
    (title, slug, excerpt, content, category, tags_csv, published, seo_title, seo_description, og_image_url, publish_date, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))
  `);

  try {
    stmt.run(
      title,
      slug,
      (body.excerpt || "").toString().trim(),
      (body.content || "").toString().trim() || "<p>Write your post here.</p>",
      (body.category || "").toString().trim(),
      (body.tags_csv || "").toString().trim(),
      boolToInt(body.published),
      (body.seo_title || "").toString().trim(),
      (body.seo_description || "").toString().trim(),
      (body.og_image_url || "").toString().trim()
    );
  } catch (e) {
    return res.status(400).send("Error creating post: " + e.message);
  }
  res.redirect("/admin/posts");
});

app.get("/admin/posts/:id/edit", requireAdmin, (req, res) => {
  const post = qaPostById.get(req.params.id);
  if (!post) return res.status(404).send("Not found");
  render(res, "admin/posts_form", { active: "", meta: metaFor(req, { title: "Edit Post — SweepCodes" }), post });
});

app.post("/admin/posts/:id", requireAdmin, (req, res) => {
  const body = req.body || {};
  const id = req.params.id;
  const current = qaPostById.get(id);
  if (!current) return res.status(404).send("Not found");

  const title = (body.title || "").toString().trim();
  let slug = (body.slug || "").toString().trim();
  if (!slug) slug = slugify(title);

  const stmt = db.prepare(`
    UPDATE posts SET
      title=?, slug=?, excerpt=?, content=?, category=?, tags_csv=?, published=?,
      seo_title=?, seo_description=?, og_image_url=?, updated_at=datetime('now')
    WHERE id=?
  `);

  try {
    stmt.run(
      title,
      slug,
      (body.excerpt || "").toString().trim(),
      (body.content || "").toString().trim(),
      (body.category || "").toString().trim(),
      (body.tags_csv || "").toString().trim(),
      boolToInt(body.published),
      (body.seo_title || "").toString().trim(),
      (body.seo_description || "").toString().trim(),
      (body.og_image_url || "").toString().trim(),
      id
    );
  } catch (e) {
    return res.status(400).send("Error updating post: " + e.message);
  }
  res.redirect("/admin/posts");
});

app.post("/admin/posts/:id/delete", requireAdmin, (req, res) => {
  db.prepare("DELETE FROM posts WHERE id=?").run(req.params.id);
  res.redirect("/admin/posts");
});

// Pages CRUD (legal pages)
app.get("/admin/pages", requireAdmin, (req, res) => {
  const pages = qaPages.all();
  render(res, "admin/pages_list", { active: "", meta: metaFor(req, { title: "Admin Pages — SweepCodes" }), pages });
});

app.get("/admin/pages/:id/edit", requireAdmin, (req, res) => {
  const page = qaPageById.get(req.params.id);
  if (!page) return res.status(404).send("Not found");
  render(res, "admin/pages_form", { active: "", meta: metaFor(req, { title: "Edit Page — SweepCodes" }), page });
});

app.post("/admin/pages/:id", requireAdmin, (req, res) => {
  const body = req.body || {};
  const id = req.params.id;
  const current = qaPageById.get(id);
  if (!current) return res.status(404).send("Not found");

  const stmt = db.prepare(`
    UPDATE pages SET title=?, content=?, updated_at=datetime('now') WHERE id=?
  `);
  stmt.run(
    (body.title || "").toString().trim(),
    (body.content || "").toString().trim(),
    id
  );
  res.redirect("/admin/pages");
});

// --- 404
app.use((req, res) => {
  res.status(404).send("Not found");
});

// --- Start
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("SweepCodes listening on", PORT));
